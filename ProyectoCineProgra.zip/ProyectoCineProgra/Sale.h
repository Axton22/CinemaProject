#pragma once
class Sale
{
private:
	int customerId;
	int customerCardNumber;

public:
	Sale(){}
	Sale(int _customerId, int _customerCardNumber);
};