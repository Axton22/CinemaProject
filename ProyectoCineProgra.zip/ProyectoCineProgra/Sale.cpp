#include "Sale.h"

Sale::Sale(int _customerId, int _customerCardNumber)
{
	this->customerId = _customerId;
	this->customerCardNumber = _customerCardNumber;
}
