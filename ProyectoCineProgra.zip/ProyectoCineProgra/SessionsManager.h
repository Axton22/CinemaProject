#pragma once
#include "Movie.h"
#include "Room.h"
#include "Schedule.h"
#include "CinemaManager.h"

class SessionsManager
{
private: 

	static const int maxSessions = 5;
	CinemaManager movieSessions[maxSessions];
	int index;
	bool movieSet;
	bool roomSet;
	bool scheduleSet;
	CinemaManager aux;

public: 
	SessionsManager();

	CinemaManager movieSessionKeeper();
	void showMoviesAvailable();

	void setMovieSet(bool _movieSet);
	bool getMovieSet();
	void setRoomSet(bool _roomSet);
	bool getRoomSet();
	void setScheduleSet(bool _scheduleSet);
	bool getScheduleSet();
 };