#include <iostream>
#include  "Movie.h"
#include "CinemaManager.h"

using namespace std;

int main() {
	CinemaManager showMenu;
	showMenu.menu();

	return 0;
}