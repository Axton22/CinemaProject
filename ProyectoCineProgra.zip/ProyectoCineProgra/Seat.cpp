#include "Seat.h"

Seat::Seat(int _seatNumber, string _availability)
{
	this->seatNumber = _seatNumber;
	this->availability = _availability;
}
