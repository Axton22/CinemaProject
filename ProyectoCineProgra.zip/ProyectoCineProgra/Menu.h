#pragma once
class Menu
{
private:


public:

};