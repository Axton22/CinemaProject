#include "Booking.h"

Booking::Booking(double _totalPrice, int _bookingNumber)
{
	this->totalPrice = _totalPrice;
	this->bookingNumber = _bookingNumber;
}
