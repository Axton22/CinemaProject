#pragma once

#include <iostream>
#include <stdlib.h>
#include "Movie.h"
#include "Room.h"
#include "Schedule.h"
#include "SessionsManager.h"

class CinemaManager {
private:
	Movie movie;
	Room room;
	Schedule schedule;
	SessionsManager aux;

public:
	CinemaManager() {};
	CinemaManager(Movie _movie, Room _room, Schedule _schedule);

	void menu();
	Movie addMovie();
	Room enableRoom();
	Schedule movieSchedule();

	void setMovie(Movie _movie);
	Movie getMovie();
	void setRoom(Room _room);
	Room getRoom();
	void setSchedule(Schedule _schedule);
	Schedule getSchedule();
};