#include "SessionsManager.h"

SessionsManager::SessionsManager()
{
	for (int i = 0; i < maxSessions; i++)
	{
		movieSessions[i] = CinemaManager();
	}

	index = 0;
	movieSet = false;
	roomSet = false;
	scheduleSet = false;
}

CinemaManager SessionsManager::movieSessionKeeper()
{
	if (getMovieSet() && getRoomSet() && getScheduleSet()) {

		if (index < 5)
		{
			Movie movie = aux.addMovie();
			Room room = aux.enableRoom();
			Schedule schedule = aux.movieSchedule();

			movieSessions[index].setMovie(movie);
			movieSessions[index].setRoom(room);
			movieSessions[index].setSchedule(schedule);
			return movieSessions[index++];
		}
	}
}

void SessionsManager::showMoviesAvailable()
{
	for (int i = 0; i < index; i++)
	{
		Movie movie = movieSessions[i].getMovie();
		cout << "Movie name: " << movie.getName() << endl;
	}
}

void SessionsManager::setMovieSet(bool _movieSet)
{
	this->movieSet = _movieSet;
}

bool SessionsManager::getMovieSet()
{
	return movieSet;
}

void SessionsManager::setRoomSet(bool _roomSet)
{
	this->roomSet = _roomSet;
}

bool SessionsManager::getRoomSet()
{
	return roomSet;
}

void SessionsManager::setScheduleSet(bool _scheduleSet)
{
	this->scheduleSet = _scheduleSet;
}

bool SessionsManager::getScheduleSet()
{
	return scheduleSet;
}



